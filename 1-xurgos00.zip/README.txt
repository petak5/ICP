Pouzite zdroje:
  - https://github.com/eclipse/paho.mqtt.cpp/blob/master/src/samples/async_subscribe.cpp
  - https://www.eclipse.org/paho/files/cppdoc/classmqtt_1_1callback.html
  - https://www.eclipse.org/paho/files/cppdoc/classmqtt_1_1iaction__listener.html
